import csv
import math

def gaus(A,cl,col,l, fold_size):
	count=0.0
	sum1=0.0
	dsq=0.0
	#print "Training"
	for i in range(no_row):
		if(i>=l and i<l+ fold_size):
			continue
		if(actual[dataset[i][no_col]]==cl):
			sum1+=float(dataset[i][col])
			count+=1
	u=sum1/count
	for i in range(no_row):
		if(i>=l and i<l+ fold_size):
			continue
		if(actual[dataset[i][no_col]]==cl):
			diff=float(dataset[i][col])-u
			dsq+=diff*diff
	varience=dsq/(count-1)
	std=math.sqrt(varience)
	power=-((A-u)*(A-u))/(2*varience)
	nume=math.exp(power)
	den=math.sqrt(2*math.pi)*std
	ans=nume/den
	#print("ans:",ans)
	return ans


def crossvalid(prob1,prob2, fold_size):
	l=0
	count=0
	eravg=0.0
	#print no_row
	k=1
	#print "Testing"
	while(l<no_row):
		ans=[]
		act=[]
		errate=0.0
		err=0.0
		#print("Training")
		for i in range(no_row):
			if(not(i>=l and i<l+fold_size)):
				continue
			#print("prob1",prob1)
			pro1=prob1
			pro2=prob2
			act.append((actual[dataset[i][no_col]])*0.1)
			#print(pro1)
			#print(pro2)
			for j in range(no_col):	
				pro1*=gaus(float(dataset[i][j]),0.0,j,l, fold_size)	
				pro2*=gaus(float(dataset[i][j]),1.0,j,l, fold_size)
			if(pro1>pro2):
				ans1=0.0
				ans.append(ans1)
			else:
				ans1=1.0
				ans.append(ans1)

			if(ans1!=actual[dataset[i][no_col]]):
				err+=1
				
		print ans
		print act
		errate=err/ fold_size
		print('Fold %d' %k)
		erate=errate*100
		print('Error Rate %f' %erate)
		srate=(1-errate)*100
		print('Success Rate %f' %srate)
		#print errate
		k+=1 
		eravg+=errate
		count+=1
		l+=fold_size
	#print("count",count)
	#print count
	eravg=eravg/count
	return (1-eravg)
		
					
					
def nb(fold_size):	 
	p1=0.0
	p2=0.0
	#print(no_row)
	for i in range(no_row):
		if(actual[dataset[i][no_col]]==0):
			p1+=1
		else:
			p2+=1
	prob1=p1/no_row
	prob2=p2/no_row
	print ("Probability of occurance of class R : %f" %prob1)
	print ("Probability of occurance of class M : %f" %prob2)
	return (crossvalid(prob1,prob2, fold_size))
	    
	
dataset = list(list())

option=input("1.Sonar 2.Iris 3.Spectf 4.Diabetes\n")
if(option==1):
	filename = 'sonar.csv'
elif(option==2):
	filename = 'iris.csv'
elif(option==3):
	filename = 'spectf.csv'
else:
	filename = 'diabetes.csv'

with open(filename, 'rb') as csvfile:
    r = csv.reader(csvfile)
    for k,i in enumerate(r):
        #if k==0:
         #   continue
        dataset.append(i)

no_col = len(dataset[1])-1
print("No.of features in the current dataset are %d" %no_col)
no_row = len(dataset)

fold_size=no_row/10

cvs=[]
for i in range(len(dataset)):
	cvs.append(dataset[i][-1])
actual1=set(cvs)
actual1=list(actual1)
#actual1[0]=1.0
#actual1[1]=0.0
#for i in range(len(actual1)):
    #print(dataset[i])
actual = { actual1[0] : 1, actual1[1] : 0}
#print actual
prob1=0.0
prob2=0.0
print("the average accuracy rate is:" ,nb(fold_size)*100)








