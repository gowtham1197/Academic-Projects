import csv
from random import seed
from random import randrange
from math import sqrt


def load_csv(filename):
	lines=csv.reader(open(filename,"rb"))
	dataset=list(lines)
	for i in range(len(dataset)):
		if dataset[i][-1]=="M" or dataset[i][-1]=="Iris-setosa" or dataset[i][-1]=="Yes" or dataset[i][-1]=="1":
			dataset[i][-1]=1
		else:
			dataset[i][-1]=0
	for i in range(len(dataset)):
		dataset[i]=[float(x) for x in dataset[i]]
	return dataset


def dataset_minmax(dataset):
	combined = list()
	for i in range(len(dataset[0])):
		col=[row[i] for row in dataset]
		min_v=min(col)
		max_v=max(col)
		combined.append([min_v, max_v])
	return combined


def normalize(dataset, combined):
	for row in dataset:
		for i in range(len(row)):
			row[i] = (row[i] - combined[i][0]) / (combined[i][1] - combined[i][0])


def cross_validation(dataset, k):
	split=list()
	copy=list(dataset)
	fold_size=int(len(dataset) / k)
	for i in range(k):
		fold=list()
		while len(fold) < fold_size:
			index=randrange(len(copy))
			fold.append(copy.pop(index))
		split.append(fold)
	return split


def rmse_c(actual, predicted,test_set):
	count=0
	sum_error = 0.0
	l=0.0
	for i in range(len(actual)):
		
		if predicted[i]>0.5:
			predicted[i]=1.0
		else:
			predicted[i]=0.0
		prediction_error=predicted[i] - actual[i]
		sum_error+=(prediction_error ** 2)
		if prediction_error == 0:
			count+=1
	
	mean_error=sum_error/float(len(actual))
	l=(count/float(len(test_set)))*100.0
	return sqrt(mean_error),l


def sgd_algorithm(dataset, algo, k, *args):
	folds=cross_validation(dataset, k)
	scores=list()
	l=0.0
	m=1
	print("\nEstimating Co-efficeints with %d epoch and %0.2f learning rate" % (epoch, learning_rate))
	for i in folds:
		print ""
		print("Fold %d:" % m)
		trainSet=list(folds)
		
		trainSet.remove(i)
		trainSet=sum(trainSet, [])
		print ("Length of Training Set: %d" % len(trainSet))
		#print trainSet
		testSet=list()
		for row in i:
			row_copy = list(row)
			testSet.append(row_copy)
			row_copy[-1] = None
		predicted = algo(trainSet, testSet, *args)
		actual = [row[-1] for row in i]
		
		print("Length of Testing Set: %d\n" % len(testSet))
		print("Actual Values")
		print actual
		rmse=rmse_c(actual, predicted,testSet)[0]
		scores.append(rmse)
		c=rmse_c(actual, predicted, testSet)[1]
		l=l+c
		print("Predicted Values")
		print predicted

		print("\nAccuracy of Fold %d: %d%%\n" % (m,c))
		print "------------------------------------------------------------------------------------------------------------------------------------------------\n"
		m=m+1
	l = l/5
	print("Accuracy: %0.3f%%" % l)
	return scores


def predict(row, coefficients):
	y=coefficients[0]
	for i in range(len(row)-1):
		y+=coefficients[i + 1]*row[i]
	return y


def coeff(train, learning_rate, epoch):
	coef=[0.0 for i in range(len(train[0]))]
	
	for epoch in range(epoch):
		for row in train:
			y=predict(row, coef)
			error=y-row[-1]
			coef[0]= coef[0]-learning_rate * error
			for i in range(len(row)-1):
				coef[i + 1]=coef[i + 1]-learning_rate * error * row[i]
	return coef


def linear_reg(train, test, learning_rate, epoch):
	pred=list()
	coef=coeff(train, learning_rate, epoch)
	for row in test:
		y=predict(row, coef)
		pred.append(y)
	return(pred)

option=input("1.Sonar 2.Iris 3.Spectf 4.Diabetes\n")
if(option==1):
	filename = 'sonar.csv'
elif(option==2):
	filename = 'iris.csv'
elif(option==3):
	filename = 'spectf.csv'
else:
	filename = 'diabetes.csv'

dataset=load_csv(filename)
minmax=dataset_minmax(dataset)
normalize(dataset, minmax)
k=5
learning_rate=0.01
epoch=50
scores=sgd_algorithm(dataset, linear_reg, k, learning_rate, epoch)
#print('Scores: %s' % scores)

#print('Mean RMSE: %.3f' % (sum(scores)/float(len(scores))))