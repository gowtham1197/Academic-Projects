from random import seed
from csv import reader
from random import randrange
from math import sqrt


def readfile(file):
	dataset=list()
	with open(file, 'r') as data:
		csv_reader = reader(data)
		for row in csv_reader:
			dataset.append(row)
	return dataset


def string2float(dataset,col):
	for row in dataset:
		row[col]=float(row[col].strip())

def string2int(dataset, col):
	cv = [row[col] for row in dataset]
	cv1 = set(cv)
	corr = dict()
	for i, j in enumerate(cv1):
		corr[j] = i
	for row in dataset:
		row[col] = corr[row[col]]
	return corr

def split(dataset, fold): ##############Creating 5 separate folds######################
	split = list()
	dup = list(dataset)
	n_rows = int(len(dataset) / fold)
	for i in range(fold):
		x = list()
		while len(x) < n_rows:
			r_num = randrange(len(dup))
			x.append(dup.pop(r_num))
		split.append(x)
	#print split
	return split

def acc(original, outcome):
	c = 0
	for i in range(len(original)):
		if original[i] == outcome[i]:
			c += 1
	return c / float(len(original)) * 100.0


def run_algo(dataset, algo, fold, *args):
	separation = split(dataset, fold)
	f_vs = list()
	for fold in separation:
		training = list(separation)
		training.remove(fold)
		training = sum(training, [])
		testing = list()
		for row in fold:
			row_dup = list(row)
			testing.append(row_dup)
			row_dup[-1] = None
		m=len(training)
		n=len(testing)
		print('Length of training set : %d ' % m)
		print('Length of testing set : %d\n' % n)
		outcome = algo(training, testing, *args)
		#print("Length of outcomes:")
		#print(len(outcome))
		original = [row[-1] for row in fold]
		acc_value = acc(original, outcome)
		f_vs.append(acc_value)

	return f_vs

def split2(c_num, j, dataset):
	lc, rc = list(), list()
	for row in dataset:
		if row[c_num] < j:
			lc.append(row)
		else:
			rc.append(row)
	return lc, rc


def gini_measure(grps, cvls):
	n= float(sum([len(grps) for i in grps]))
	gini = 0.0
	for i in grps:
		m = float(len(i))
		if m == 0:
			continue
		initial = 0.0
		for k in cvls:
			z = [row[-1] for row in i].count(k) / m
			#print("Value of z: %d" %z)
			initial += z * z
		gini += (1.0 - initial) * (m / n)
		#print gini
	return gini
 
def split_point(dataset, n_cols):
	cvls = list(set(row[-1] for row in dataset))
	#print cvls
	b_index, b_value, b_score, b_groups = 999, 999, 999, None
	cols = list()
	while len(cols) < n_cols:
		c_num = randrange(len(dataset[0])-1)
		if c_num not in cols:
			cols.append(c_num)
	for c_num in cols:
		for row in dataset:
			grps = split2(c_num, row[c_num], dataset)
			gini = gini_measure(grps, cvls)
			if gini < b_score:
				b_index, b_value, b_score, b_groups = c_num, row[c_num], gini, grps
	return {'index':b_index, 'value':b_value, 'groups':b_groups}



def t_node(grp):
	results = [row[-1] for row in grp]
	return max(set(results), key=results.count)

def divide(node, max_height, minimum, n_cols, height):
	lc, rc = node['groups']
	del(node['groups'])
	# check for a no split
	if not lc or not rc:
		node['lc'] = node['rc'] = t_node(lc + rc)
		return
	# check for max depth
	if height >= max_height:
		node['lc'], node['rc'] = t_node(lc), t_node(rc)
		return
	# process left child
	if len(lc) <= minimum:
		node['lc'] = t_node(lc)
	else:
		node['lc'] = split_point(lc, n_cols)
		divide(node['lc'], max_height, minimum, n_cols, height+1)
	# process right child
	if len(rc) <= minimum:
		node['rc'] = t_node(rc)
	else:
		node['rc'] = split_point(rc, n_cols)
		divide(node['rc'], max_height, minimum, n_cols, height+1)


def constrcut_tree(train, max_height, minimum, n_cols):
	root = split_point(train, n_cols)
	#print root
	#print "\n\n\n"
	divide(root, max_height, minimum, n_cols, 1)
	return root

def calculate(node, row):
	if row[node['index']] < node['value']:
		if isinstance(node['lc'], dict):
			return calculate(node['lc'], row)
		else:
			return node['lc']
	else:
		if isinstance(node['rc'], dict):
			return calculate(node['rc'], row)
		else:
			return node['rc']

def subsample(dataset, ratio):
	sample = list()
	n_sample = round(len(dataset) * ratio)
	while len(sample) < n_sample:
		index = randrange(len(dataset))
		sample.append(dataset[index])
	#print len(sample)
	return sample


def bagging_predict(trees, row):
	outcomes = [calculate(tree, row) for tree in trees]
	#print outcomes
	#print "\n\n\n"
	return max(set(outcomes), key=outcomes.count)
 

def random_forest(train, test, max_height, minimum, size, n_trees, n_cols):
	trees = list()
	for i in range(n_trees):
		sample = subsample(train, size)
		tree = constrcut_tree(sample, max_height, minimum, n_cols)
		#print tree
		#print "\n\n\n"
		trees.append(tree)
	print("Trees :\n\n")
	c=len(trees)
	print('No. of trees are %d\n' %c)
	for i in range(len(trees)):
		print trees[i]
		print "\n\n" 
	outcomes = [bagging_predict(trees, row) for row in test]
	return outcomes


option=input("1.sonar.scv\n2.iris.csv\n3.spectf.csv\n4.diabetes.csv\n")
if(option==1):
	file = 'sonar.csv'
elif(option==2):
	file='iris.csv'
elif(option==3):
	file='spectf.csv'
else:
	file='diabetes.csv'

print('Reading dataset from csv file............')
dataset = readfile(file)
for i in range(0, len(dataset[0])-1):
	string2float(dataset, i)
string2int(dataset, len(dataset[0])-1)
# evaluate algorithm
fold = 5
max_height = 10
minimum = 1
size = 1.0
n_cols = int(sqrt(len(dataset[0])-1))
m_acc=[]
for n_trees in [1, 5, 10]:
	print("No. of folds considered:%d" %fold)
	print('Running algorithm for %d trees' % n_trees)
	f_vs = run_algo(dataset, random_forest, fold, max_height, minimum, size, n_trees, n_cols)
	print('Accuracy of each fold: %s' % f_vs)
	m_acc.append((sum(f_vs)/float(len(f_vs))))
	print('Mean Accuracy : %.3f%%' %(sum(f_vs)/float(len(f_vs))))
	print "---------------------------------------------------------------------------\n\n"
print "\n\n"
print "Final Accuracies obtained:"
print "No. of n_trees\t\t Mean Accuracy"
print ('1 \t\t\t %.3f' %m_acc[0])
print ('5 \t\t\t %.3f' %m_acc[1])
print ('10 \t\t\t %.3f' %m_acc[2])