<div  id="menu">
    <ul>
        <li id="menuHome"><a href=".">Home</a></li>
        <li id="menuAttandance" ><a href="AddAttendance.php">Attandance</a></li>
        <li id="menuEmployee" ><a href="EmployeeRegister.php">Register Emp</a></li>
        <li id="menuEmployeeList" ><a href="EmployeeList.php">Emp List</a></li>
        <li id="menuSalaryList" ><a href="SalaryDetail.php">Salary</a></li>
        <li id="menuEmployeeReport" ><a href="EmployeeReport.php">Emp Report</a></li>
        <li id="menuEmployeeList" ><a href="process/processLogout.php">Logout</a></li>
    </ul>
</div>	