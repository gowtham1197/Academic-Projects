<div id="footer">
    <p>
        &copy; 2012 <strong>Logistic Infotech</strong> |
        <a href="#" title="Website Templates">website templates</a> by <a href="#">styleshout</a> |
        Valid <a href="#">XHTML</a> | 
        <a href="#">CSS</a>   		
    </p>
</div>
<?php $_SESSION['Msg']=''; ?>